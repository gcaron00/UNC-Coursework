package assignment5_f20;

public class Edge {
	private final long weight;
	private String eLabel;
	private long idNum;
	private String dLabel;
	  
	public Edge(long weight, long idNum, String dLabel, String eLabel) {
	   this.weight = weight;
	   this.eLabel = eLabel;
	   this.idNum = idNum;
	   this.dLabel = dLabel;
	}
	
	public long getIdNum() {
		return idNum;
	}
	
	public String getLabel() {
		return eLabel;
	}
	
	public long getWeight() {
		return weight;
	}
	
	public String getDlabel() {
		return dLabel;
	}
}
package assignment5_f20;

public class DiGraphPlayground {

  public static void main (String[] args) {
  
      // thorough testing is your responsibility
      //
      // you may wish to create methods like 
      //    -- print
      //    -- sort
      //    -- random fill
      //    -- etc.
      // in order to convince yourself your code is producing
      // the correct behavior
      exTest();
    }
  
    public static void exTest(){
      DiGraph d = new DiGraph();
      d.addNode(1, "a");
      d.addNode(3, "b");
      d.addNode(7, "c");
      d.addNode(0, "d");
      d.addNode(4, "e");
      //d.addNode(6, "si");
      d.addEdge(0, "a", "b", 1, null);
      d.addEdge(1, "a", "c", 3, null);
      d.addEdge(2, "a", "d", 5, null);
      d.addEdge(3, "a", "e", 9, null);
      d.addEdge(4, "b", "c", 1, null);
      d.addEdge(5, "b", "d", 2, null);
      d.addEdge(6, "b", "e", 7, null);
      d.addEdge(7, "c", "d", 2, null);
      d.addEdge(8, "c", "e", 5, null);
      d.addEdge(9, "d", "e", 3, null);
      d.delNode("b");
      System.out.println("numEdges: "+d.numEdges());
      System.out.println("numNodes: "+d.numNodes());
      
      ShortestPathInfo[] b = d.shortestPath("a");
      for (ShortestPathInfo k: b) {
    	  System.out.println(k.getDest());
    	  System.out.println(k.getTotalWeight());
      }
      System.out.println(d.getGraph().get(d.getLabels().get("d")).getOutEdges().get("e").getWeight());
    }
}
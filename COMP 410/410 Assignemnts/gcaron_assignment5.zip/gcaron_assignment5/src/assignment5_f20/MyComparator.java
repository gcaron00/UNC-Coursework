package assignment5_f20;

import java.util.Comparator;

class MyComparator implements Comparator<Node> {

    public int compare(Node a, Node b) {
    	return (int) (a.getDv() - b.getDv());
    }
}
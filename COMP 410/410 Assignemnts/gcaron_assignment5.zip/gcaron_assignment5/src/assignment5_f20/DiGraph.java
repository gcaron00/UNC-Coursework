package assignment5_f20;

import java.util.HashMap;
import java.util.PriorityQueue;

public class DiGraph implements DiGraphInterface {
	
	private HashMap<String, Long> labels;
	private HashMap<Long, Node> graph;
	private long nodeNum;
	private long edgeNum;
	  
	public DiGraph(){
	    this.labels = new HashMap<String, Long>();
	    this.graph = new HashMap<Long, Node>();
	    this.nodeNum = 0;
	    this.edgeNum = 0;
	}
	  
	public HashMap<Long, Node> getGraph() {
		return graph;
	}
	
	public HashMap<String, Long> getLabels() {
		return labels;
	}
	
	@Override
	public boolean addNode(long idNum, String label) {
		if(labels.get(label) != null || graph.get(idNum) != null || idNum < 0) { return false; }
		labels.put(label, idNum);
		graph.put(idNum, new Node(label));
		nodeNum++;
		return true;
	}

	@Override
	public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {
		if (labels.get(sLabel) == null || labels.get(dLabel) == null || idNum < 0) {return false;}
		for (Node nodeSet : graph.values()) {
			for (Edge edge : nodeSet.getOutEdges().values()) {
				if(edge.getIdNum() == idNum) {return false;}
			}
		}
		if (graph.get(labels.get(sLabel)).getOutEdges().get(dLabel) != null) {return false;}
		graph.get(labels.get(sLabel)).getOutEdges().put(dLabel, new Edge(weight, idNum, dLabel, eLabel));
		edgeNum++;
		return true;
	}

	@Override
	public boolean delNode(String label) {
		if (labels.get(label) == null) {return false;}
		for(String s: graph.get((labels.get(label))).getOutEdges().keySet()) {
			edgeNum--;
		}
		graph.remove((labels.get(label)));
		labels.remove(label);
		for(Node n: graph.values()) {
			if (n.getOutEdges().get(label) != null) {
				n.getOutEdges().remove(label);
				edgeNum--;
			}
//			for(String s: n.getOutEdges().keySet()) {
//				if (label.equals(s)) {
//					n.getOutEdges().remove(s);
//					edgeNum--;
//				}
//			}
		}
		
		//for(String s: graph.get(labels.get(Label)).getOutEdges().get(dLabel))
		nodeNum--;
		return true;
	}

	@Override
	public boolean delEdge(String sLabel, String dLabel) {
		if (labels.get(sLabel) == null || labels.get(dLabel) == null) {return false;}
		if (graph.get(labels.get(sLabel)).getOutEdges().get(dLabel) == null) {return false;}
		graph.get(labels.get(sLabel)).getOutEdges().remove(dLabel);
		edgeNum--;
		return true;
	}

	@Override
	public long numNodes() {
		return this.nodeNum;
	}

	@Override
	public long numEdges() {
		return this.edgeNum;
	}

	@Override
	public ShortestPathInfo[] shortestPath(String label) {
		//set known=false pv=null and dv=-1 for each node
		for (Node n: graph.values()) {
			n.setKnown(false);
			n.setDv(-1);
		}
		int i = 0;
		ShortestPathInfo[] spi = new ShortestPathInfo[(int) numNodes()];
		PriorityQueue<Node> pq = new PriorityQueue<Node>(new MyComparator());		
		Node currentNode = graph.get(labels.get(label));
		currentNode.setDv(0);
		pq.add(currentNode);
		while(pq.size() > 0) {
			currentNode = pq.peek();
			pq.remove(currentNode);
			if (currentNode.getKnown() == false) {
				currentNode.setKnown(true);
				for (Edge edge: currentNode.getOutEdges().values()) {
					Node k = graph.get(labels.get(edge.getDlabel()));
					if (k.getDv() > (currentNode.getDv() + edge.getWeight()) || k.getDv() < 0) {
						k.setDv(currentNode.getDv() + edge.getWeight());
						//a.setPv(currentNode);
						pq.add(k);
					}
				}
//				spi[i] = new ShortestPathInfo(currentNode.getLabel(), currentNode.getDv());
//				i++;
			}	
		}
		for (Node n: graph.values()) {
			spi[i] = new ShortestPathInfo(n.getLabel(), n.getDv());
			i++;
		}
		return spi;
	}
	
}
package assignment5_f20;

import java.util.HashMap;

public class Node {
	private HashMap<String, Edge> out_edges;
	private boolean known;
	private long dv;
	private String label;
	  
	public Node(String label) {
	   this.out_edges = new HashMap<String, Edge>();
	   this.label = label;
	}
	
	public String getLabel() {
		return label;
	}
	
	public HashMap<String, Edge> getOutEdges() {
		return out_edges;
	}	
	
	public long getDv() {
		return dv;
	}
	
	public boolean getKnown( ) {
		return known;
	}
	
	public void setKnown(boolean _known) {
		known = _known;
	}
	
	public void setDv(long _dv) {
		dv = _dv;
	}
}

package assignment4_f20;

public class MinBinHeap implements Heap {
  private CacheFrame[] array; // load this array
  private int size;      // how many items currently in the heap
  private int arraySize; // Everything in the array will initially
                         // be null. This is ok! Just build out
                         // from array[1]

  public MinBinHeap(int nelts) {
    this.array = new CacheFrame[nelts+1];  // remember we dont use slot 0
    this.arraySize = nelts+1;
    this.size = 0;
    this.array[0] = new CacheFrame(null, 0); // 0 not used, so this is arbitrary
  }

  // Please do not remove or modify this method! Used to test your entire Heap.
  	@Override
  	public CacheFrame[] getHeap() { return this.array; }

	// set map slot for insert, delMin, incElt and decElt
  	//remove from map for del min
  	
  	@Override
	public void insert(CacheFrame elt) {
  		size++;
  		array[size] = elt;
		elt.setSlot(size);	
		int parent_idx = (int) Math.floor((elt.getSlot()) / 2);
		while (parent_idx != 0) {
			CacheFrame parent = array[parent_idx];
			if (parent.getPriority() > elt.getPriority()) {
				parent.setSlot(elt.getSlot());
				elt.setSlot(parent_idx);
				// here
				array[parent.getSlot()] = parent;
				array[elt.getSlot()] = elt; 
				parent_idx = (int) Math.floor((elt.getSlot()) / 2);
			} else {
				break;
			}
		}
	}
	
	@Override
	public void delMin() {
		if (size == 0) {
			return;
		}
		size--;
		CacheFrame last = array[size + 1];
		array[1] = last;
		array[size + 1] = null;
		last.setSlot(1);
		

		while (true) {
			int minidx;
			int leftidx = last.getSlot() * 2;
			int rightidx = last.getSlot() * 2 + 1;
			if (leftidx <= size && rightidx <= size) {
				if (array[leftidx].getPriority() < array[rightidx].getPriority()) {
					minidx = leftidx;
				} else {
					minidx = rightidx;
				}
			} else if(leftidx <= size && rightidx > size) {
				minidx = leftidx;
			} else {
				break;
			}
			CacheFrame min = array[minidx];
			if (last.getPriority() > min.getPriority()) {
				min.setSlot(last.getSlot());
				last.setSlot(minidx);
				array[min.getSlot()] = min;
				array[last.getSlot()] = last;
				//here
			} else {
				break;
			}
		}
	}
	
	@Override
	public CacheFrame getMin() {
		return array[1];
	}
	
	@Override
	public int size() {
		return size;
	}
	
	@Override
	public void incElt(CacheFrame elt) {
		elt.setPriority(elt.getPriority() + 1);
		
		while (true) {
			int minidx;
			int leftidx = elt.getSlot() * 2;
			int rightidx = elt.getSlot() * 2 + 1;
			if (leftidx <= size && rightidx <= size) {
				if (array[leftidx].getPriority() < array[rightidx].getPriority()) {
					minidx = leftidx;
				} else {
					minidx = rightidx;
				}
			} else if(leftidx <= size && rightidx > size) {
				minidx = leftidx;
			} else {
				break;
			}
			CacheFrame min = array[minidx];
			if (elt.getPriority() > min.getPriority()) {
				min.setSlot(elt.getSlot());
				elt.setSlot(minidx);
				array[min.getSlot()] = min;
				array[elt.getSlot()] = elt;
				//here
			} else {
				break;
			}
		}
	}
	
	@Override
	public void decElt(CacheFrame elt) {
		if (elt.getPriority() > 1) {
			elt.setPriority(elt.getPriority() - 1);
			int parent_idx = (int) Math.floor((elt.getSlot()) / 2);
			while (parent_idx != 0) {
				CacheFrame parent = array[parent_idx];
				if (parent.getPriority() > elt.getPriority()) {
					parent.setSlot(elt.getSlot());
					elt.setSlot(parent_idx);
					// here
					array[parent.getSlot()] = parent;
					array[elt.getSlot()] = elt; 
					parent_idx = (int) Math.floor((elt.getSlot()) / 2);
				} else {
					break;
				}
			}
		}
			
		
	}

  //===============================================================
  //
  // here down you implement the ops in the interface
  //
  //===============================================================

}
package assignment3_f20;

public class HashMap_imp implements HashMap { 
	HMCell[] tab;
	int nelts;
  
  //-------------------------------------------------------------

	HashMap_imp (int num) { 
		this.tab = new HMCell[num];
    // for (int i=0; i<num; i++) { tab[i] = null; }
    // we can rely on the Java compiler to fill the table array with nulls
    // another way would be Array.fill()
		this.nelts = 0; 
	}

  //-------------------------------------------------------------
  
	public int hash (String key, int tabSize) {
		int hval = 7;
		for (int i=0; i<key.length(); i++) {
			hval = (hval*31) + key.charAt(i);
		}
		hval = hval % tabSize;
		if (hval<0) { hval += tabSize; }
		return hval;
	}
  
  //-------------------------------------------------------------

  // dont change 
	@Override
  	public HMCell[] getTable() { return this.tab; }

	public Value put(String k, Value v) {
		if (tab.length == 0) { return null; }
		int hval = hash(k, tab.length);
		HMCell cell = this.tab[hval];
		HMCell parent = null;
		while(true) {
			if (cell != null) {
				if (cell.getKey().equals(k)) {
					Value old = cell.getValue();
					cell.setValue(v);
					return old;
				} else {
					parent = cell;
					cell = cell.getNext();
				}
			} else {
				if (parent == null) {
					this.tab[hval] = new HMCell_imp(k, v);
				} else {
					parent.setNext(new HMCell_imp(k, v));
				} 
				this.nelts++;
				if(lambda() >= 1) {
					extend();
				}
				return null;
			}
		}
		
	}

	public Value get(String k) {
		if (tab.length == 0) { return null; }
		int hval = hash(k, tab.length);
		HMCell cell = this.tab[hval];
		while(true) {
			if (cell != null) {
				if (cell.getKey().equals(k)) {
					return cell.getValue();
				} else {
					cell = cell.getNext();
				}
			} else {
				return null;
			}
		}
	}

	public void remove(String k) {
		if (tab.length == 0) { return; }
		int hval = hash(k, tab.length);
		HMCell cell = this.tab[hval];
		HMCell parent = null;
		while(true) {
			if (cell != null) {
				if (cell.getKey().equals(k)) {
					if (parent == null) {
						this.tab[hval] = cell.getNext();
					} else {
						parent.setNext(cell.getNext());
					}
					this.nelts--;
					return;
				} else {
					parent = cell;
					cell = cell.getNext();
				}
			} else {
				return;
			}
		}
	}

	public boolean hasKey(String k) {
		if (get(k) == null) {
			return false;
		} else { return true; }
	}

	public int size() {
		return this.nelts;
	}
	
	public String maxKey() {
		String[] keys = getKeys();
		if (keys.length == 0) { return null; }
		String max = keys[0];
		for(int i = 1; i < keys.length; i++) {
			if (max.compareTo(keys[i]) < 0) {
				max = keys[i];
			}	
		}
		return max;
	}

	public String minKey() {
		String[] keys = getKeys();
		if (keys.length == 0) { return null; }
		String min = keys[0];
		for(int i = 1; i < keys.length; i++) {
			if (min.compareTo(keys[i]) > 0) {
				min = keys[i];
			}	
		}
		return min;		
	}

	@Override
	public String[] getKeys() {
		String[] keys = new String[this.nelts];
		if (tab.length == 0) { return keys; }
		int idx = 0;
		for(int i = 0; i < tab.length; i++) {
			HMCell cell = this.tab[i];
			if (cell != null) {
				keys[idx] = cell.getKey();
				idx++;
				boolean j = true;
				while(j) {
					if (cell.getNext() != null) {
						keys[idx] = cell.getNext().getKey();
						idx++;
						cell = cell.getNext();
					} else { j = false;}
				}
			}
		}
		return keys;
	}

	public double lambda() { 
		return ((double) nelts)/tab.length;
	}

	public double extend() {
		HMCell[] oldTab = tab;
		nelts = 0;
		tab = new HMCell[oldTab.length * 2];
		for(int i = 0; i < oldTab.length; i++) {
			HMCell cell = oldTab[i];
			if (cell != null) {
				put(cell.getKey(), cell.getValue());
				boolean j = true;
				while(j) {
					if (cell.getNext() != null) {
						put(cell.getNext().getKey(), cell.getNext().getValue());
						cell = cell.getNext();
					} else { j = false;}
				}
			}
		}		
		return lambda();
	}
  
  //-------------------------------------------------------------

    
  //-------------------------------------------------------------
  // here down... you fill in the implementations for
  // the other interface methods
  
  
  //-------------------------------------------------------------
  
}
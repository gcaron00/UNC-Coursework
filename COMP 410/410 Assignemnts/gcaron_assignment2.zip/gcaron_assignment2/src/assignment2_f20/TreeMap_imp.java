package assignment2_f20;

//--------------------------------------------------------------

public class TreeMap_imp implements TreeMap { 
	TMCell root;
	int size;
  // add fields as you need to in order to provide the required behavior
  // also you may add private methods to assist you as needed
  // in implementing
  
  //-------------------------------------------------------------

	TreeMap_imp () { 
		root = null;
		size = 0;
		
    // for added fields you can add appropriate initialization code here
	}

  //-------------------------------------------------------------

  // dont change, we need this for grading
	@Override
	public TMCell getRoot() { return this.root; }
  
  //-------------------------------------------------------------
  // "height" is a complete implementation 
  // of the public interface method height
  // it is here to illustrate fr you how the textbook sets up 
  // the method implementation as recursion
  // you may include this in your project directly

	public int height() { // public interface method signature
  // this method is the public interface method
  // it is not recursive, but it calls a recursive
  // private method and passes it access to the tree cells
		return height_r(this.getRoot());
	}
	private int height_r(TMCell c) { 
  // inner method with different signature
  // this helper method uses recursion to traverse
  // and process the recursive structure of the tree of cells
		if (c==null) return -1;
		int lht = height_r(c.getLeft());
		int rht = height_r(c.getRight());
		return Math.max(lht,rht) + 1;
	}

	
  
  //-------------------------------------------------------------
  // here down... you fill in the implementations for
  // the other interface methods
	public Value put(String k, Value v) { //recursive
		if (this.getRoot() == null) {
			this.root = new TMCell_imp(k, v);
			this.size++;
			return null;
		} else {
			return put_r(k, v, this.getRoot());	
		}
	}
	private Value put_r(String k, Value v, TMCell r) {
		int compare = r.getKey().compareTo(k);
		if (compare < 0) { 
			if (r.getRight() == null) {
				r.setRight(new TMCell_imp(k, v));
				this.size++;
				return null;
			} return put_r(k, v, r.getRight());
		} else if (compare > 0) {
			if (r.getLeft() == null) {
				r.setLeft(new TMCell_imp(k, v));
				this.size++;
				return null;
			} return put_r(k, v, r.getLeft());
		} else {  
			Value holder = r.getValue();
			this.root.setValue(v);
			return holder;
		} 
	}
	public Value get(String k) { //recursive
		if (this.getRoot() == null) {
			return null;
		} else {
			return get_r(k, this.getRoot());
		}
	}
	private Value get_r(String k, TMCell r) {
		int compare = r.getKey().compareTo(k);
		if (compare < 0) { 
			if (r.getRight() == null) {
				return null;
			} return get_r(k, r.getRight());
		} else if (compare > 0) {
			if (r.getLeft() == null) {
				return null;
			} return get_r(k, r.getLeft());
		} else {  
			return r.getValue();
		} 
	}
	public void remove(String k) {  //recursive
		if (this.getRoot() == null) {
			return;
		} else {
			remove_r(k, this.getRoot(), null, true);
		}
	}
	private void remove_r(String k, TMCell r, TMCell parent, boolean side) {
		int compare = r.getKey().compareTo(k);
		if (compare < 0) { 
			if (r.getRight() != null) {
				remove_r(k, r.getRight(), r, true);
			} 
		} else if (compare > 0) {
			if (r.getLeft() != null) {
				remove_r(k, r.getLeft(), r, false);
			} 
		} else {  
			if (r.getLeft() == null && r.getRight() == null) { //case of no children
				if (parent != null && side == true) {
					parent.setRight(null);
				} else if (parent != null && side == false){
					parent.setLeft(null);
				} else {
					this.root = null;
				}
			} else if (r.getLeft() == null && r.getRight() != null) { 
				if (parent != null && side == true) { // r one right child, parent right, r not root
					parent.setRight(r.getRight());
				} else if (parent != null && side == false) { // r one right, parent left, r not root
					parent.setLeft(r.getRight());
				} else {
					this.root = r.getRight(); // r one right, r is root
				}
			} else if(r.getLeft() != null && r.getRight() == null) {
				if (parent != null && side == true) { // r one left child, parent right, r not root
					parent.setRight(r.getLeft());
				} else if (parent != null && side == false) { // r one left, parent left, r not root
					parent.setLeft(r.getLeft());
				} else {
					this.root = r.getLeft(); // r one left, r is root
				}
			} else if (r.getLeft() != null && r.getRight() != null) { //case of both children
				TMCell low = get_rRlow_set_rRside(r.getRight(), r, side);
				low.setRight(r.getRight());
				low.setLeft(r.getLeft());
				if (parent != null && side == true) {
					parent.setRight(low);
				} else if (parent!= null && side == false) {
					parent.setLeft(low);
				} else {
					this.root = low;
				}
			}
			this.size--;
		}
	}
	private TMCell get_rRlow_set_rRside(TMCell t, TMCell parent2, boolean side) {
		if (t.getLeft() == null) {
			if (t.getRight() != null && side == false) {
				parent2.setLeft(t.getRight());
			} else if (t.getRight() != null && side == true){
				parent2.setRight(t.getRight());			
			} else if (side == true){
				parent2.setRight(null);
			} else {
				parent2.setLeft(null);
			}
			return t;
		} else  {
			return get_rRlow_set_rRside(t.getLeft(), t, false);
		}
	}
	public boolean hasKey(String k) {  //recursive
		Value x = get(k);
		if (x == null) {
			return false;
		} else {
			return true;
		}
	}
	public int size() {
		return this.size;
	}
	public String maxKey() { //recursive	
		if (this.getRoot() == null) {          
			return null;
		} else {
			/*String[] max = getKeys_r(this.getRoot(), new String[this.size], new TMCell[this.size], 0, -1);       less code but O(n) instead of O(logn)
			return max[size-1];*/
			return get_max(this.getRoot());
		}
	}
	private String get_max(TMCell r) {
		if (r.getRight() == null) {
			return r.getKey();
		} else {
			return get_max(r.getRight());
		}
	}
	public String minKey() { //recursive
		if (this.getRoot() == null) {          
			return null;
		} else {
			/*String[] max = getKeys_r(this.getRoot(), new String[this.size], new TMCell[this.size], 0, -1);       less code but O(n) instead of O(logn)
			return max[0];*/
			return get_min(this.getRoot());
		}
	}
	private String get_min(TMCell r) {
		if (r.getLeft() == null) {
			return r.getKey();
		} else {
			return get_min(r.getLeft());
		}
	}
	public String[] getKeys() {
		return getKeys_r(this.getRoot(), new String[this.size], new TMCell[this.size], 0, -1);
	}
	private String[] getKeys_r(TMCell r, String[] keys, TMCell[] parents, int keysi, int parenti) {
		if (r == null) {
			if (parenti < 0) {
				return keys;
			} else {
				keys[keysi] = parents[parenti].getKey();
				keysi++;
				parenti--;
				return getKeys_r(parents[parenti+1].getRight(), keys, parents, keysi, parenti);
			}
		}
		if (r.getLeft() == null) {
			keys[keysi] = r.getKey();
			keysi++;
			if (r.getRight() != null) {
				return getKeys_r(r.getRight(), keys, parents, keysi, parenti);
			} else {
				if (parenti >= 0) {
					keys[keysi] = parents[parenti].getKey();
					keysi++;
					parenti--;
					return getKeys_r(parents[parenti+1].getRight(), keys, parents, keysi, parenti);
				} else {
					return keys;
				}
				
			}	
		} else {
			parenti++;
			parents[parenti] = r;
			return getKeys_r(r.getLeft(), keys, parents, keysi, parenti);
		}
	}
	
  //-------------------------------------------------------------
  //
  // remember to implement the required recursion as noted
  // in the interface definition
  //
  //-------------------------------------------------------------
		
}
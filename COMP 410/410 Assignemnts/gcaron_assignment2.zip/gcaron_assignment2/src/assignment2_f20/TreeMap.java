package assignment2_f20;
public interface TreeMap extends Map {
	  public String maxKey();  // recursive
	  public String minKey();  // recursive
	  public String[] getKeys(); 
	  public int height();  // recursive, given as an example

	  // leave this in... for grader use
	  // also specific to tree structure
	  public TMCell getRoot();
}

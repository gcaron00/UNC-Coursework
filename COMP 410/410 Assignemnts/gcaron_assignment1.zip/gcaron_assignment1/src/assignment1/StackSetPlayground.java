package assignment1;

public class StackSetPlayground {

  public static void main(String[] args) { 
    /*
     here you can instantiate your StackSet and play around with it to check correctness. 
     We've graciously also provided you a bit of extra test data for debugging.
     It doesn't matter what you have in here. We will not grade it. 
     This is for your use in testing your implementation.
    */
    StackSet set = new StackSet(4);
    System.out.println(set);
    
    System.out.println(set.isEmpty());
    System.out.println(set.isFull());  
    set.push(1);
    set.push(2);
    set.push(4);
    set.push(1);
    set.printSet();
    set.push(1);
    set.pop();
    set.printSet();
    set.push(1);
    set.push(2);
    set.push(3);
    set.push(3);
    set.push(4);
    set.push(5);
    set.printSet();
   
   
    set.pop();
    set.pop();
    System.out.println(set.pop());
    set.printSet();
    
    
    StackSet set2 = new StackSet(0);
    set2.push(2);
    set2.printSet();
    System.out.println(set2.push(4));
  }
  
}
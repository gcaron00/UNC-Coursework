/**
 * COMP 410
 * See inline comment descriptions for methods we need that are
 * not described in the interface.
 *
*/
package assignment1;

public class StackSet implements StackSet_Interface {
	private Node head;  //this will be the entry point to your linked list 
                      //( it points to the first data cell, the top for a stack )
	private final int limit;  //defines the maximum size the stackset may contain
	private int size;   //current count of elements in the stackset 
  
	public StackSet( int maxNumElts ){ //this constructor is needed for testing purposes. 
		head = null;                 //Please don't modify what you see here!
		limit = maxNumElts;          //you may add fields if you need to
		size = 0;
}
  
	public boolean push(double newVal) {
		if (size == 0) {
			if (limit > 0) {
				head = new NodeImpl(newVal, null);
				size++;
				return true;
			} else {
				return false;
			}
		} 
		if (head.getValue() == newVal) {
			return true;
		}		
		Node nextSearch = head;
		for (int i = 1; i < size; i++) {
			if (nextSearch.getNext().getValue() == newVal) {
				Node newHead = nextSearch.getNext();
				nextSearch.setNext(newHead.getNext());
				newHead.setNext(head);
				head = newHead;
				return true;
			}
			nextSearch = nextSearch.getNext();
		}
		if (size < limit) {
			Node newNode = new NodeImpl(newVal);
			newNode.setNext(head);
			head = newNode;
			size++;
			return true;
		}
		return false;
	}
	
	public boolean pop() {
		if (head == null) {
			return false;
		} else {
			head = head.getNext();
			size--;
			return true;
		}
	}
	
	public double peek() {
		if (head == null) {
			return Double.NaN;
		} else {
			return head.getValue();
		}
	}
	
	public boolean contains(double searchVal) {
		Node searchNext = head;
		for (int i = 0; i < size; i++) {
			if (searchNext.getValue() == searchVal) {
				return true;
			}
			searchNext = searchNext.getNext();
		}
		return false;
	}
	
	public int size() {
		return size;
	}
	
	public int limit() {
		return limit;
	}
	
	public boolean isEmpty() {
		if (head == null) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isFull() {
		if (size == limit) {
			return true;
		} else {
			return false;
		}
	}
	
	void printSet() {
		Node nextNode = head;
		System.out.print("{");
		for (int i = 0; i < size; i++) {
			if (i == size - 1) {
				System.out.print(nextNode.getValue());
			} else {
				System.out.print(nextNode.getValue() + ", ");
			}
			
			nextNode = nextNode.getNext();
		}
		System.out.println("}");
	}
	
	
//implement all methods of the interface, and 
//also include the getRoot method below that we made for testing purposes. 
//Feel free to implement private helper methods!
//you may add any fields you need to add to make it all work... 
	public Node getRoot(){ //leave this method as is, used by the grader to grab 
		return head;         //your data list easily.
	}

}
package assignment1;

public interface Node {
  public double getValue();
  public void setNext(Node next);
  public Node getNext();
}